define({
  "_themeLabel": "접을 수 있는 테마",
  "_layout_default": "기본 레이아웃",
  "_layout_layout1": "레이아웃 1"
});