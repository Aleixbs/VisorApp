define({
  "_widgetLabel": "Controlador do Cabeçalho",
  "signin": "Iniciar sessão",
  "signout": "Terminar Sessão",
  "about": "Sobre",
  "signInTo": "Iniciar sessão em",
  "cantSignOutTip": "Esta função encontra-se indisponível em modo de previsualização.",
  "more": "mais"
});