define({
  "_widgetLabel": "Kontroler zaglavlja",
  "signin": "Prijavite se",
  "signout": "Odjavite se",
  "about": "Više o",
  "signInTo": "Prijavite se na",
  "cantSignOutTip": "Ova funkcija nije dostupna u režimu pregledanja.",
  "more": "više"
});